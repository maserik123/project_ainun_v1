<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class WriterAlreadyOpenedException
 */
class WriterAlreadyOpenedException extends WriterException
{
}
